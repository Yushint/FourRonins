import sys
import log, prof, registr, redactor, about
from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox, QInputDialog, QFileDialog
from PyQt5.QtGui import QPixmap
import json


class App(QMainWindow, log.i_MainWindow, prof.Ui_MainWindow, registr.Ui_MainWindow, redactor.Ui_MainWindow,
          about.Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.pushButton_2.clicked.connect(self.reg)
        self.pushButton.clicked.connect(self.ent_check)
        self.show()

    def reg_check(self):
        try:
            with open('bd', 'r'):
                pass
        except FileNotFoundError:
            with open('bd', 'w') as tt:
                json.dump({}, tt)
        with open('bd', 'r') as f:
            bd = json.load(f)

        ers = []

        if self.RlineEdit.text() in bd:
            ers.append("имя пользователя занято")
        elif self.RlineEdit_2.text() != self.RlineEdit_3.text():
            ers.append("пароли не совпадают")
        elif "@" and "." not in self.RlineEdit_4.text():
            ers.append("неврная электронная почта")
        elif not self.RcheckBox.isChecked():
            ers.append("лицензионное соглашение не принято")

        if ers == []:
            bd[self.RlineEdit.text()] = [self.RlineEdit_2.text(), self.RlineEdit_4.text(), '', '', '', '', '', []]
            with open('bd', 'w') as f:
                json.dump(bd, f)
            self.ex()
        else:
            QMessageBox.about(self, "", " ".join(ers))

    def reg(self):
        self.RsetupUi(self)
        self.Rlabel.setText("Регистрация")
        self.Rlabel_2.setText("Имя пользователя")
        self.Rlabel_3.setText("Пароль")
        self.Rlabel_4.setText("Повторите пароль")
        self.Rlabel_5.setText("Email адресс")
        self.RcheckBox.setText("Я принимаю лицензионное соглашение")
        self.RpushButton.setText("Создать учетную запись")
        self.RpushButton.clicked.connect(self.reg_check)
        self.СpushButton.setText("Назад")
        self.СpushButton.clicked.connect(self.ex)

    def ent_check(self, e):
        with open('bd', 'r') as f:
            bd = json.load(f)

        if self.textEdit.toPlainText() in bd and bd[self.textEdit.toPlainText()][0] == self.textEdit_2.text():
            self.I = self.textEdit.toPlainText()
            self.ent()
        elif e:
            self.I = e
            self.ent()
        else:
            QMessageBox.about(self, "неверный пароль", "неверный логин или пароль")
            self.textEdit_2.setText("")

    def ent(self):
        with open('bd', 'r') as f:
            bd = json.load(f)

        try:
            with open('users', 'r'):
                pass
        except FileNotFoundError:
            with open('users', 'w') as tt:
                json.dump({}, tt)
        with open('users', 'r') as f:
            us = json.load(f)

        if self.I not in us:
            us[self.I] = len(bd[self.I][-1])
        elif self.I in us:
            us[self.I] = len(bd[self.I][-1])

        with open('users', 'w') as f:
            json.dump(us, f)

        self.SubsetupUi(self)
        self.Slabel.setText("{} {} {} {}".format(bd[self.I][2], bd[self.I][3], bd[self.I][4], bd[self.I][5]))
        self.Slabel_3.setText("уровень: {}".format(len(bd[self.I][-1])))
        self.Slabel_4.setText("топ участников")
        self.SpushButton.setText("выход")
        self.SpushButton.clicked.connect(self.ex)
        self.SpushButton_2.setText("редактировать профиль")
        self.SpushButton_2.clicked.connect(self.redact)
        self.SpushButton_3.setText("дополнить")
        self.SpushButton_3.clicked.connect(self.add)
        self.SpushButton_4.setText("о нас")
        self.SpushButton_4.clicked.connect(self.ab)
        self.SpushButton_5.setText("обновить")
        self.SpushButton_5.clicked.connect(self.rel)

        if bd[self.I][-2] != '':
            self.Slabel_2.setPixmap(QPixmap(bd[self.I][-2]))
            self.Slabel_2.setScaledContents(True)

        if bd[self.I][-1] != []:
            for i in bd[self.I][-1]:
                self.listView.addItem(i)

        list_d = list(us.items())
        list_d.sort(key=lambda i: i[1], reverse=True)
        for i in list_d:
            self.listView_2.addItem(bd[i[0]][3] + ' ' + bd[i[0]][2] + ' ' + str(i[1]))

    def redact(self):
        self.ex()
        self.REsetupUi(self)
        self.REpushButton.setText("сохранить")
        self.REpushButton.clicked.connect(self.save)
        self.RElabel.setText("Редактировать профиль")
        self.RElabel_2.setText("Фамилия")
        self.RElabel_3.setText("Имя")
        self.RElabel_4.setText("Школа")
        self.RElabel_5.setText("Класс")
        self.REpushButton_2.setText("Загрузить фото профиля")
        self.REpushButton_2.clicked.connect(self.load)
        self.REpushButton_3.setText("Назад")
        self.REpushButton_3.clicked.connect(self.rel)

    def ab(self):
        self.ex()
        self.AsetupUi(self)
        self.ApushButton.setText("назад")
        self.ApushButton.clicked.connect(self.rel)
        self.Alabel.setText("О нас")
        self.Alabel_2.setText("""                                      «Электронное портфолио»
У каждого обучающегося должно быть портфолио, но к сожалению, мало у
кого оно есть и далеко не все ведут его осознанно. Информация о наших
достижениях нигде не хранится, хотя это отличная возможность оставить
цифровой след. Думаю, каждому было бы интересно сейчас взять свое
школьное портфолио и увидеть, благодаря каким мероприятиям вы
овладели имеющимися навыками. Что за секции вы посещали. И где все
полученные сертификаты, грамоты и дипломы за участие в мероприятиях.""")
        self.Alabel_2.wordWrap()

        self.Alabel_3.setText("Наш вебсайт")
        self.Alabel_3.setOpenExternalLinks(True)
        self.Alabel_3.setText('<a href="https://www.patreon.com/fouRonins/creators/"> Наш вебсайт </a>')

        self.Alabel_4.setText("Наш  Patreon")
        self.Alabel_4.setOpenExternalLinks(True)
        self.Alabel_4.setText('<a href="https://www.patreon.com/fouRonins/creators/"> Наш Patreon </a>')

    def load(self):
        with open('bd', 'r') as f:
            bd = json.load(f)
        path = QFileDialog.getOpenFileName()
        bd[self.I][-2] = path[0]
        with open('bd', 'w') as f:
            json.dump(bd, f)

    def save(self):
        with open('bd', 'r') as f:
            bd = json.load(f)
        if self.RElineEdit.text() != '': bd[self.I][2] = self.RElineEdit.text()
        if self.RElineEdit_2.text() != '': bd[self.I][3] = self.RElineEdit_2.text()
        if self.RElineEdit_3.text() != '': bd[self.I][4] = self.RElineEdit_3.text()
        if self.RElineEdit_4.text() != '': bd[self.I][5] = self.RElineEdit_4.text()
        with open('bd', 'w') as f:
            json.dump(bd, f)

    def ex(self):
        self.hide()
        self.__init__()

    def rel(self):
        self.ex()
        self.ent_check(self.I)

    def add(self):
        with open('bd', 'r') as f:
            bd = json.load(f)
        text, ok = QInputDialog.getText(self, 'Дополнить достижения', 'введите достижение:')
        if ok and text != '':
            bd[self.I][-1].append(text)
            with open('bd', 'w') as f:
                json.dump(bd, f)


def run():
    app = QApplication(sys.argv)
    window = App()
    sys.exit(app.exec_())


if __name__ == '__main__': run()
