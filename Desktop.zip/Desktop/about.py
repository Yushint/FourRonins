# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/Users/sergey/PycharmProjects/тест/untitled.ui'
#
# Created by: PyQt5 UI code generator 5.14.0
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
    def AsetupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(640, 480)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.ApushButton = QtWidgets.QPushButton(self.centralwidget)
        self.ApushButton.setGeometry(QtCore.QRect(10, 10, 112, 32))
        self.ApushButton.setObjectName("pushButton")
        self.Alabel = QtWidgets.QLabel(self.centralwidget)
        self.Alabel.setGeometry(QtCore.QRect(270, 60, 58, 16))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.Alabel.setFont(font)
        self.Alabel.setObjectName("label")
        self.Alabel_2 = QtWidgets.QLabel(self.centralwidget)
        self.Alabel_2.setGeometry(QtCore.QRect(60, 90, 481, 171))
        self.Alabel_2.setObjectName("label_2")
        self.Alabel_3 = QtWidgets.QLabel(self.centralwidget)
        self.Alabel_3.setGeometry(QtCore.QRect(270, 270, 211, 21))
        self.Alabel_3.setObjectName("label_3")
        self.Alabel_4 = QtWidgets.QLabel(self.centralwidget)
        self.Alabel_4.setGeometry(QtCore.QRect(270, 300, 211, 21))
        self.Alabel_4.setObjectName("label_4")
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.ApushButton.setText(_translate("MainWindow", "назад"))
        self.Alabel.setText(_translate("MainWindow", "О нас"))
        self.Alabel_2.setText(_translate("MainWindow", "текст"))
        self.Alabel_3.setText(_translate("MainWindow", "Наш вебсайт"))
        self.Alabel_4.setText(_translate("MainWindow", "Наш  Patreon"))
