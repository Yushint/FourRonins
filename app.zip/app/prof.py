# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/Users/sergey/PycharmProjects/тест/untitled.ui'
#
# Created by: PyQt5 UI code generator 5.14.0
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
    def SubsetupUi(self, mainWindow):
        mainWindow.setObjectName("MainWindow")
        mainWindow.resize(640, 480)
        self.centralwidget = QtWidgets.QWidget(mainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.Slabel = QtWidgets.QLabel(self.centralwidget)
        self.Slabel.setGeometry(QtCore.QRect(90, 10, 211, 31))
        self.Slabel.setObjectName("label")
        self.SpushButton = QtWidgets.QPushButton(self.centralwidget)
        self.SpushButton.setGeometry(QtCore.QRect(531, 0, 101, 31))
        self.SpushButton.setObjectName("pushButton")
        self.Slabel_2 = QtWidgets.QLabel(self.centralwidget)
        self.Slabel_2.setGeometry(QtCore.QRect(10, 10, 75, 75))
        self.Slabel_2.setStyleSheet("background-color: rgb(219, 240, 253)")
        self.Slabel_2.setText("")
        self.Slabel_2.setObjectName("label_2")
        self.SpushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.SpushButton_2.setGeometry(QtCore.QRect(90, 40, 211, 31))
        self.SpushButton_2.setObjectName("pushButton_2")
        self.SpushButton_3 = QtWidgets.QPushButton(self.centralwidget)
        self.SpushButton_3.setGeometry(QtCore.QRect(10, 420, 371, 32))
        self.SpushButton_3.setObjectName("pushButton_3")

        self.SpushButton_4 = QtWidgets.QPushButton(self.centralwidget)
        self.SpushButton_4.setGeometry(QtCore.QRect(430, 0, 101, 31))
        self.SpushButton_4.setObjectName("pushButton_4")

        self.SpushButton_5 = QtWidgets.QPushButton(self.centralwidget)
        self.SpushButton_5.setGeometry(QtCore.QRect(319, 0, 101, 31))
        self.SpushButton_5.setObjectName("pushButton_5")

        self.listView = QtWidgets.QListWidget(self.centralwidget)
        self.listView.setGeometry(QtCore.QRect(10, 101, 371, 321))
        self.listView.setObjectName("listView")
        self.listView_2 = QtWidgets.QListWidget(self.centralwidget)
        self.listView_2.setGeometry(QtCore.QRect(410, 100, 191, 321))
        self.listView_2.setObjectName("listView_2")
        self.Slabel_3 = QtWidgets.QLabel(self.centralwidget)
        self.Slabel_3.setGeometry(QtCore.QRect(97, 80, 281, 20))
        self.Slabel_3.setObjectName("label_3")
        self.Slabel_4 = QtWidgets.QLabel(self.centralwidget)
        self.Slabel_4.setGeometry(QtCore.QRect(410, 80, 191, 16))
        self.Slabel_4.setObjectName("label_4")
        mainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(mainWindow)
        self.statusbar.setObjectName("statusbar")
        mainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(mainWindow)
        QtCore.QMetaObject.connectSlotsByName(mainWindow)

    def retranslateUi(self, mainWindow):
        _translate = QtCore.QCoreApplication.translate
        mainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.SpushButton.setText(_translate("MainWindow", "выход"))
        self.SpushButton_2.setText(_translate("MainWindow", "редактировать информацию"))
        self.SpushButton_3.setText(_translate("MainWindow", "дополнить"))

        self.SpushButton_4.setText(_translate("MainWindow", "о нас"))
        self.SpushButton_5.setText(_translate("MainWindow", "обновить"))

        self.Slabel_3.setText(_translate("MainWindow", "уровень: 0"))
        self.Slabel_4.setText(_translate("MainWindow", "топ участников"))
