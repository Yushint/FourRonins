# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/Users/sergey/PycharmProjects/тест/untitled.ui'
#
# Created by: PyQt5 UI code generator 5.14.0
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
    def RsetupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(640, 480)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.Rlabel = QtWidgets.QLabel(self.centralwidget)
        self.Rlabel.setGeometry(QtCore.QRect(150, 75, 171, 31))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.Rlabel.setFont(font)
        self.Rlabel.setObjectName("label")
        self.RlineEdit = QtWidgets.QLineEdit(self.centralwidget)
        self.RlineEdit.setGeometry(QtCore.QRect(150, 140, 321, 31))
        self.RlineEdit.setObjectName("lineEdit")
        self.RlineEdit_2 = QtWidgets.QLineEdit(self.centralwidget)
        self.RlineEdit_2.setGeometry(QtCore.QRect(150, 190, 321, 31))
        self.RlineEdit_2.setEchoMode(QtWidgets.QLineEdit.Password)
        self.RlineEdit_2.setObjectName("lineEdit_2")
        self.RlineEdit_3 = QtWidgets.QLineEdit(self.centralwidget)
        self.RlineEdit_3.setGeometry(QtCore.QRect(150, 240, 321, 31))
        self.RlineEdit_3.setEchoMode(QtWidgets.QLineEdit.Password)
        self.RlineEdit_3.setObjectName("lineEdit_3")
        self.RlineEdit_4 = QtWidgets.QLineEdit(self.centralwidget)
        self.RlineEdit_4.setGeometry(QtCore.QRect(150, 290, 321, 31))
        self.RlineEdit_4.setObjectName("lineEdit_4")
        self.Rlabel_2 = QtWidgets.QLabel(self.centralwidget)
        self.Rlabel_2.setGeometry(QtCore.QRect(150, 120, 141, 16))
        self.Rlabel_2.setObjectName("label_2")
        self.Rlabel_3 = QtWidgets.QLabel(self.centralwidget)
        self.Rlabel_3.setGeometry(QtCore.QRect(150, 170, 141, 16))
        self.Rlabel_3.setObjectName("label_3")
        self.Rlabel_4 = QtWidgets.QLabel(self.centralwidget)
        self.Rlabel_4.setGeometry(QtCore.QRect(150, 220, 141, 16))
        self.Rlabel_4.setObjectName("label_4")
        self.Rlabel_5 = QtWidgets.QLabel(self.centralwidget)
        self.Rlabel_5.setGeometry(QtCore.QRect(150, 270, 141, 16))
        self.Rlabel_5.setObjectName("label_5")
        self.RcheckBox = QtWidgets.QCheckBox(self.centralwidget)
        self.RcheckBox.setGeometry(QtCore.QRect(150, 330, 301, 20))
        self.RcheckBox.setObjectName("checkBox")
        self.RpushButton = QtWidgets.QPushButton(self.centralwidget)
        self.RpushButton.setGeometry(QtCore.QRect(150, 360, 321, 32))
        self.RpushButton.setObjectName("pushButton")

        self.СpushButton = QtWidgets.QPushButton(self.centralwidget)
        self.СpushButton.setGeometry(QtCore.QRect(10, 10, 101, 32))
        self.СpushButton.setObjectName("СpushButton")

        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.Rlabel.setText(_translate("MainWindow", "Регистрация"))
        self.Rlabel_2.setText(_translate("MainWindow", "Имя пользователя"))
        self.Rlabel_3.setText(_translate("MainWindow", "Пароль"))
        self.Rlabel_4.setText(_translate("MainWindow", "Повторите пароль"))
        self.Rlabel_5.setText(_translate("MainWindow", "Email адресс"))
        self.RcheckBox.setText(_translate("MainWindow", "Я принимаю лицензионное соглашение"))
        self.RpushButton.setText(_translate("MainWindow", "Создать учетную запись"))
        self.CpushButton.setText(_translate("MainWindow", "назад"))
