import sys
import log, prof, registr
from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox, QInputDialog
from PyQt5 import QtGui
import json


class App(QMainWindow, log.i_MainWindow, prof.Ui_MainWindow, registr.Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.pushButton_2.clicked.connect(self.reg)
        self.pushButton.clicked.connect(self.ent_check)
        self.show()

    def reg_check(self):
        try:
            with open('bd', 'r'):
                pass
        except FileNotFoundError:
            with open('bd', 'w') as tt:
                json.dump({}, tt)
        with open('bd', 'r') as f:
            bd = json.load(f)

        ers = []

        if self.RlineEdit.text() in bd:
            ers.append("имя пользователя занято")
        elif self.RlineEdit_2.text() != self.RlineEdit_3.text():
            ers.append("пароли не совпадают")
        elif "@" and "." not in self.RlineEdit_4.text():
            ers.append("неврная электронная почта")
        elif not self.RcheckBox.isChecked():
            ers.append("лицензионное соглашение не принято")

        if ers == []:
            bd[self.RlineEdit.text()] = [self.RlineEdit_2.text(), self.RlineEdit_4.text(), '', '', '', '', []]
            with open('bd', 'w') as f:
                json.dump(bd, f)
            self.ex()
        else:
            QMessageBox.about(self, "", " ".join(ers))

    def reg(self):
        self.RsetupUi(self)
        self.Rlabel.setText("Регистрация")
        self.Rlabel_2.setText("Имя пользователя")
        self.Rlabel_3.setText("Пароль")
        self.Rlabel_4.setText("Повторите пароль")
        self.Rlabel_5.setText("Email адресс")
        self.RcheckBox.setText("Я принимаю лицензионное соглашение")
        self.RpushButton.setText("Создать учетную запись")
        self.RpushButton.clicked.connect(self.reg_check)
        self.СpushButton.setText("Назад")
        self.СpushButton.clicked.connect(self.ex)

    def ent_check(self, e):
        with open('bd', 'r') as f:
            bd = json.load(f)

        if self.textEdit.toPlainText() in bd and bd[self.textEdit.toPlainText()][0] == self.textEdit_2.text():
            self.I = self.textEdit.toPlainText()
            self.ent()
        elif e:
            self.I = e
            self.ent()
        else:
            QMessageBox.about(self, "неверный пароль", "неверный логин или пароль")
            self.textEdit_2.setText("")

    def ent(self):
        with open('bd', 'r') as f:
            bd = json.load(f)

        try:
            with open('users', 'r'):
                pass
        except FileNotFoundError:
            with open('users', 'w') as tt:
                json.dump({}, tt)
        with open('users', 'r') as f:
            us = json.load(f)

        if self.I not in us:
            us[self.I] = len(bd[self.I][-1])
        elif self.I in us:
            us[self.I] = len(bd[self.I][-1])

        with open('users', 'w') as f:
            json.dump(us, f)

        self.SubsetupUi(self)
        self.Slabel.setText("{}".format(self.I))
        self.Slabel_3.setText("уровень: {}".format(len(bd[self.I][-1])))
        self.Slabel_4.setText("топ участников")
        self.SpushButton.setText("выход")
        self.SpushButton.clicked.connect(self.ex)
        self.SpushButton_2.setText("редактировать профиль")
        self.SpushButton_3.setText("дополнить")
        self.SpushButton_3.clicked.connect(self.add)
        self.SpushButton_4.setText("о нас")
        self.SpushButton_5.setText("обновить")
        self.SpushButton_5.clicked.connect(self.rel)
        if bd[self.I][-1] != []:
            for i in bd[self.I][-1]:
                 self.listView.addItem(i)

        list_d = list(us.items())
        list_d.sort(key=lambda i: i[1], reverse=True)
        for i in list_d:
            self.listView_2.addItem(i[0] + ' ' + str(i[1]))

    def ex(self):
        self.hide()
        self.__init__()

    def rel(self):
        self.ex()
        self.ent_check(self.I)

    def add(self):
        with open('bd', 'r') as f:
            bd = json.load(f)
        text, ok = QInputDialog.getText(self, 'Дополнить достижения', 'введите достижение:')
        if ok and text != '':
            bd[self.I][-1].append(text)
            with open('bd', 'w') as f:
                json.dump(bd, f)


def run():
    app = QApplication(sys.argv)
    window = App()
    sys.exit(app.exec_())


if __name__ == '__main__': run()
