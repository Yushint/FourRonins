# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/Users/sergey/PycharmProjects/тест/untitled.ui'
#
# Created by: PyQt5 UI code generator 5.14.0
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
    def REsetupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(640, 480)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.REpushButton = QtWidgets.QPushButton(self.centralwidget)
        self.REpushButton.setGeometry(QtCore.QRect(230, 300, 112, 32))
        self.REpushButton.setObjectName("pushButton")
        self.RElineEdit = QtWidgets.QLineEdit(self.centralwidget)
        self.RElineEdit.setGeometry(QtCore.QRect(140, 160, 321, 21))
        self.RElineEdit.setObjectName("lineEdit")
        self.RElineEdit_2 = QtWidgets.QLineEdit(self.centralwidget)
        self.RElineEdit_2.setGeometry(QtCore.QRect(140, 120, 321, 21))
        self.RElineEdit_2.setObjectName("lineEdit_2")
        self.RElineEdit_3 = QtWidgets.QLineEdit(self.centralwidget)
        self.RElineEdit_3.setGeometry(QtCore.QRect(140, 200, 321, 21))
        self.RElineEdit_3.setObjectName("lineEdit_3")
        self.RElineEdit_4 = QtWidgets.QLineEdit(self.centralwidget)
        self.RElineEdit_4.setGeometry(QtCore.QRect(140, 240, 321, 21))
        self.RElineEdit_4.setObjectName("lineEdit_4")
        self.RElabel = QtWidgets.QLabel(self.centralwidget)
        self.RElabel.setGeometry(QtCore.QRect(220, 70, 300, 31))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.RElabel.setFont(font)
        self.RElabel.setObjectName("label")
        self.RElabel_2 = QtWidgets.QLabel(self.centralwidget)
        self.RElabel_2.setGeometry(QtCore.QRect(140, 140, 191, 20))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.RElabel_2.setFont(font)
        self.RElabel_2.setObjectName("label_2")
        self.RElabel_3 = QtWidgets.QLabel(self.centralwidget)
        self.RElabel_3.setGeometry(QtCore.QRect(140, 100, 191, 20))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.RElabel_3.setFont(font)
        self.RElabel_3.setObjectName("label_3")
        self.RElabel_4 = QtWidgets.QLabel(self.centralwidget)
        self.RElabel_4.setGeometry(QtCore.QRect(140, 180, 191, 20))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.RElabel_4.setFont(font)
        self.RElabel_4.setObjectName("label_4")
        self.RElabel_5 = QtWidgets.QLabel(self.centralwidget)
        self.RElabel_5.setGeometry(QtCore.QRect(140, 220, 191, 20))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.RElabel_5.setFont(font)
        self.RElabel_5.setObjectName("label_5")
        self.REpushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.REpushButton_2.setGeometry(QtCore.QRect(191, 270, 191, 32))
        self.REpushButton_2.setObjectName("pushButton_2")
        self.REpushButton_3 = QtWidgets.QPushButton(self.centralwidget)
        self.REpushButton_3.setGeometry(QtCore.QRect(10, 10, 112, 32))
        self.REpushButton_3.setObjectName("pushButton_3")
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.REpushButton.setText(_translate("MainWindow", "сохранить"))
        self.RElabel.setText(_translate("MainWindow", "Редактировать профиль"))
        self.RElabel_2.setText(_translate("MainWindow", "Фамилия"))
        self.RElabel_3.setText(_translate("MainWindow", "Имя"))
        self.RElabel_4.setText(_translate("MainWindow", "Школа"))
        self.RElabel_5.setText(_translate("MainWindow", "Класс"))
        self.REpushButton_2.setText(_translate("MainWindow", "Загрузить фото профиля"))
        self.REpushButton_3.setText(_translate("MainWindow", "Назад"))
